import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-page',
  templateUrl: './other-page.component.html',
  styleUrls: ['./other-page.component.css']
})
export class OtherPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
